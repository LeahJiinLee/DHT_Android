package com.example.dell.dht;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends Activity {

    ImageView img;
    Button ledButton, fanModeButton, fanManualButton;
    String ledStatus, fanModeStatus, fanManualStatus, dustCompare;
    TextView dust, humidity, temperature;
    Handler handler;
    String serverAddr="192.168.43.119"; //웹에서 접속할 IP 변경하여 사용
    String sidoName="서울"; //시도명 변경하여 사용
    String stationName="용산구"; //측정소명 변경하여 사용
    String serviceKey="zxwQThUKZFBhNLazdsMo9RReT2DcOd7B6AlCpryaUma4u0O1gUw37H%2FZaFWLskmSxOQypN8%2B292v2ufheMZfDw%3D%3D";
    int pm10Val_num = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startActivity(new Intent(this, SplashActivity.class));

        img=(ImageView)findViewById(R.id.img);

        ledButton=(Button)findViewById(R.id.led);
        fanModeButton=(Button)findViewById(R.id.fanMode);
        fanManualButton=(Button)findViewById(R.id.fanManual);

        ledStatus="ledOn";
        fanModeStatus="fanAuto";
        fanManualStatus="fanOff";
        dustCompare="OutGood";

        dust=(TextView)findViewById(R.id.dust);
        humidity=(TextView)findViewById(R.id.humidity);
        temperature=(TextView)findViewById(R.id.temperature);

        ledButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(ledStatus.equals("ledOn")){
                    Toast.makeText(MainActivity.this, "LED OFF", Toast.LENGTH_SHORT).show();
                    ledStatus = "ledOff";
                    ledButton.setText("LED OFF");
                }
                else{
                    Toast.makeText(MainActivity.this, "LED ON", Toast.LENGTH_SHORT).show();
                    ledStatus = "ledOn";
                    ledButton.setText("LED ON");
                }
                //클릭하면 http request
                String serverAddress = serverAddr+":80";
                HttpRequestTask requestTask = new HttpRequestTask(serverAddress);
                requestTask.execute(ledStatus);
            }
        });

        fanModeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fanModeStatus.equals("fanAuto")){
                    Toast.makeText(MainActivity.this, "FAN MANUAL MODE", Toast.LENGTH_SHORT).show();
                    fanModeStatus = "fanManual";
                    fanModeButton.setText("FAN MANUAL MODE");
                    fanManualButton.setBackgroundColor(Color.parseColor("#25000000"));
                }
                else{
                    Toast.makeText(MainActivity.this, "FAN AUTO MODE", Toast.LENGTH_SHORT).show();
                    fanModeStatus = "fanAuto";
                    fanModeButton.setText("FAN AUTO MODE");
                    fanManualButton.setBackgroundColor(Color.parseColor("#10000000"));
                    fanManualStatus="fanOff";
                    fanManualButton.setText("FAN OFF");
                }
                //클릭하면 http request
                String serverAddress = serverAddr+":80";
                HttpRequestTask requestTask = new HttpRequestTask(serverAddress);
                requestTask.execute(fanModeStatus);
            }
        });

        fanManualButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(fanModeStatus.equals("fanManual")){
                    if(fanManualStatus.equals("fanOn")){
                        Toast.makeText(MainActivity.this, "FAN OFF", Toast.LENGTH_SHORT).show();
                        fanManualStatus = "fanOff";
                        fanManualButton.setText("FAN OFF");
                    }
                    else {
                        Toast.makeText(MainActivity.this, "FAN ON", Toast.LENGTH_SHORT).show();
                        fanManualStatus = "fanOn";
                        fanManualButton.setText("FAN ON");
                    }
                    //클릭하면 http request
                    String serverAddress = serverAddr+":80";
                    HttpRequestTask requestTask = new HttpRequestTask(serverAddress);
                    requestTask.execute(fanManualStatus);
                }
                else {
                    //fan자동모드상태일때 fan on/fan off를 클릭한경우
                    Toast.makeText(MainActivity.this, "Available in FAN MANUAL MODE", Toast.LENGTH_SHORT).show();
                }

            }
        });


        new DownloadWebpageTask2().execute("http://openapi.airkorea.or.kr/openapi/services/rest/ArpltnInforInqireSvc/getCtprvnRltmMesureDnsty?sidoName="+sidoName+"&numOfRows=100&ServiceKey="+serviceKey+"&ver=1.3");


        handler=new Handler();
        new Thread(){
            public void run(){
                while(true){
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            new DownloadWebpageTask().execute("http://"+serverAddr);
                        }
                    });
                    try{
                        Thread.sleep(10000);
                    }catch (InterruptedException e){e.printStackTrace();}
                }
            }
        }.start();
    }


    //AsyncTask
    public class HttpRequestTask extends AsyncTask<String, Void, String> {
        private String serverAddress;

        public HttpRequestTask(String serverAddress) {
            this.serverAddress = serverAddress;
        }

        @Override
        protected String doInBackground(String... params) {
            String val = params[0];
            final String url = "http://"+serverAddress + "/" + val;

            //okHttp 라이브러리를 사용한다.
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(url)
                    .build();
            try {
                Response response = client.newCall(request).execute();
                //Log.d(TAG, response.body().string());
                return null;
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
        }
        @Override
        protected void onCancelled() {
            super.onCancelled();
        }
    }



    private class DownloadWebpageTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {
            try {
                return (String)downloadUrl((String)urls[0]);
            } catch (IOException e) {
                return "다운로드 실패";
            }
        }

        protected void onPostExecute(String result) {

            int ugm3_data=0;

            boolean bSet_dust = false;
            boolean bSet_temperature = false;
            boolean bSet_humidity = false;

            try {
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xpp = factory.newPullParser();

                xpp.setInput(new StringReader(result));
                int eventType = xpp.getEventType();
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if(eventType == XmlPullParser.START_DOCUMENT) {
                        ;
                    } else if(eventType == XmlPullParser.START_TAG) {
                        String tag_name = xpp.getName();
                        if (tag_name.equals("dust"))
                            bSet_dust = true;
                        if (tag_name.equals("temperature"))
                            bSet_temperature = true;
                        if (tag_name.equals("humidity"))
                            bSet_humidity = true;
                    } else if(eventType == XmlPullParser.TEXT) {
                        if (bSet_dust) {
                            ugm3_data=Integer.parseInt(xpp.getText());
                            dust.setText(ugm3_data+" ㎍/m³");
                            bSet_dust = false;

                            if (ugm3_data <= 30)
                                img.setImageResource(R.drawable.img1);
                            else if(30 < ugm3_data && ugm3_data <= 80)
                                img.setImageResource(R.drawable.img2);
                            else if (80 < ugm3_data && ugm3_data <= 150)
                                img.setImageResource(R.drawable.img3);
                            else
                                img.setImageResource(R.drawable.img4);


                            if(ugm3_data > pm10Val_num)
                                dustCompare="OutGood";
                            else
                                dustCompare="OutBad";

                            //http request
                            String serverAddress = serverAddr+":80";
                            HttpRequestTask requestTask = new HttpRequestTask(serverAddress);
                            requestTask.execute(dustCompare);

                        }
                        if (bSet_temperature) {
                            temperature.setText(xpp.getText()+" ℃");
                            bSet_temperature = false;
                        }
                        if (bSet_humidity) {
                            humidity.setText(xpp.getText()+" %");
                            bSet_humidity = false;
                        }
                    } else if(eventType == XmlPullParser.END_TAG) {
                        ;
                    }
                    eventType = xpp.next();
                }
            } catch (Exception e) {}
        }

        private String downloadUrl(String myurl) throws IOException {

            HttpURLConnection conn = null;
            try {
                URL url = new URL(myurl);
                conn = (HttpURLConnection) url.openConnection();
                BufferedInputStream buf = new BufferedInputStream(conn.getInputStream());
                BufferedReader bufreader = new BufferedReader(new InputStreamReader(buf, "utf-8"));
                String line = null;
                String page = "";
                while((line = bufreader.readLine()) != null) {
                    page += line;
                }

                return page;
            } finally {
                conn.disconnect();
            }
        }
    }


    private class DownloadWebpageTask2 extends DownloadWebpageTask {

        protected void onPostExecute(String result) {

            String station="";
            String pm10Val="";

            boolean bSet_stationName = false;
            boolean bSet_pm10Value = false;

            try {
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(true);
                XmlPullParser xpp = factory.newPullParser();

                xpp.setInput(new StringReader(result));
                int eventType = xpp.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if(eventType == XmlPullParser.START_DOCUMENT) {
                        ;
                    } else if(eventType == XmlPullParser.START_TAG) {
                        String tag_name = xpp.getName();
                        if (tag_name.equals("stationName"))
                            bSet_stationName = true;
                        if (tag_name.equals("pm10Value"))
                            bSet_pm10Value = true;
                    } else if(eventType == XmlPullParser.TEXT) {
                        if (bSet_stationName) {
                            station = xpp.getText();
                            bSet_stationName = false;
                        }
                        if (bSet_pm10Value) {
                            if (station.equals(stationName)) {
                                pm10Val = xpp.getText();
                                pm10Val_num = Integer.parseInt(pm10Val);
                            }
                            bSet_pm10Value = false;
                        }
                    } else if(eventType == XmlPullParser.END_TAG) {
                        ;
                    }
                    eventType = xpp.next();
                }
            } catch (Exception e) {}

        }
    }
}